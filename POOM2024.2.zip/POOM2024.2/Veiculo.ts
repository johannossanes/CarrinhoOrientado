export class Veiculo{ //caraterístias da classe
    marca: string; 
    modelo: string;
    potencia: number;
    numeroMarchas: number; 
    marchaAtual: number; 
    velocidade: number;
    velocidadeMaxima: number;
    velocidadePorMarcha: number;

    constructor(){ //construtor da classe (new)
        this.marca = "";
        this.modelo = "";
        this.potencia = 0;
        this.numeroMarchas = 5;
        this.marchaAtual = 0;
        this.velocidade = 0;
        this.velocidadeMaxima = 120;
        this.velocidadePorMarcha = 30;
    }
    //veloicidade maxima = 120 * potencia/2
    //velocidadCompativel = velocidadePorMarcha % marchaAtual; 
    
    acelerar(): number{
        const velocidadeCompativel = this.velocidadePorMarcha * this.marchaAtual
        if(this.marchaAtual != 0 && this.velocidade <= velocidadeCompativel){
        this.velocidade += this.potencia*0.1;
       
    }
        return (this.velocidade);
    }

    frear(): number{
        if (this.velocidade > 0)
            this.velocidade = this.velocidade - 30; 
        if (this.velocidade <= 0)
            this.velocidade = 0;
        return (this.velocidade)

    }

    subirMarcha(): void{
        if(this.marchaAtual < this.numeroMarchas)
            this.marchaAtual++;
    
    }

    reduzirMarcha(): number{
        if (this.marchaAtual >= 1)
            this.marchaAtual--; 
        if (this.marchaAtual == 0){
            this.marchaAtual = 0;
        } return (this.marchaAtual) 
    }

    criaVeiculo(marca: string, modelo: string, potencia: number, numeroMarchas: number, velocidadeMaxima: number): Veiculo{
      
        this.marca = marca;
        this.modelo = modelo;
        this.potencia = potencia;
        this.numeroMarchas = numeroMarchas;
        this.velocidadeMaxima = velocidadeMaxima;
        return this;
}
}
