import { Veiculo } from "./Veiculo";

test("Deve avançar marcha", ()=> {
    //cenário
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.numeroMarchas = 5;
    veiculo.marchaAtual = 2;

    //acão
    veiculo.subirMarcha();

    //verificação
    expect(veiculo.marchaAtual).toBe(3)


})

test("Não deve avançar marcha quando já estiver na última marcha", ()=> {
    //cenário
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.numeroMarchas = 5;
    veiculo.marchaAtual = 5;

    //acão
    veiculo.subirMarcha();

    //verificação
    expect(veiculo.marchaAtual).toBe(5)


})

test("Não deve subir marcha ao frear", ()=>{
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.numeroMarchas = 5;
    veiculo.marchaAtual = 2;

    veiculo.frear();

    expect(veiculo.marchaAtual).toBe(2)

})

test("Deve diminuir a velocidade ao frear", ()=> {
    //cenário
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.numeroMarchas = 5;
    veiculo.marchaAtual = 1;
    veiculo.velocidade = 30;

    //acão
    veiculo.frear();

    //verificação
    expect(veiculo.velocidade).toBe(0)
})

test("Deve reduzir a marcha", ()=>{
     //cenário
     const veiculo = new Veiculo();
     veiculo.marca = "Fiat";
     veiculo.modelo = "Uno";
     veiculo.numeroMarchas = 5;
     veiculo.marchaAtual = 2;
 
     //acão
     veiculo.reduzirMarcha();
 
     //verificação
     expect(veiculo.marchaAtual).toBe(1)
})

test("Não deve reduzir a marcha quando já for zero", ()=>{
    //cenário
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.numeroMarchas = 5;
    veiculo.marchaAtual = 0;

    //acão
    veiculo.reduzirMarcha();

    //verificação
    expect(veiculo.marchaAtual).toBe(0)
})

test("Deve acelerar", ()=>{
    //cenário
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.numeroMarchas = 5;
    veiculo.potencia = 50;
    veiculo.marchaAtual = 1;

    //acão
    veiculo.acelerar();

    //verificação
    expect(veiculo.velocidade).toBeGreaterThan(0)
})

test("Não deve acelerar se a marcha for igual a 0", ()=>{
    //cenário
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.numeroMarchas = 5;
    veiculo.potencia = 50;
    veiculo.marchaAtual = 0;

    //acão
    veiculo.acelerar();

    //verificação
    expect(veiculo.velocidade).toBe(0)
})

test("Não deve acelerar se a marcha for 1 e a velocidade maior que velocidade compátivel", ()=> {
    //cenario
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.potencia = 50;
    veiculo.marchaAtual = 1;
    veiculo.velocidade = 35;

    //acão
    veiculo.acelerar();

    //verificação
    expect(veiculo.velocidade).not.toBeGreaterThan(35)
})


test("Deve criar veiculo", ()=>{
    //cenario
    const veiculo = new Veiculo();

    //ação
    veiculo.criaVeiculo("Fiat", "Uno", 50, 5, (120 * ((50 / 2) * 0.1) ));

    //verifiação
    expect(veiculo.marca).toBe(veiculo.marca)
    expect(veiculo.modelo).toBe(veiculo.modelo)
    expect(veiculo.potencia).toBe(veiculo.potencia)
    expect(veiculo.numeroMarchas).toBe(veiculo.numeroMarchas)
    expect(veiculo.velocidadeMaxima).toBe(veiculo.velocidadeMaxima)
})

test("Não deve acerar se a velocidade for 10 e a marcha for 5", ()=>{
    //cenario
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.marchaAtual = 5;
    veiculo.velocidade = 10;
    veiculo.potencia = 50;
    veiculo.velocidadePorMarcha = 30;
    

    //ação
    veiculo.acelerar();

    //verificação
    expect(veiculo.velocidade).toBeLessThanOrEqual(10);
})

test("Deve gerar um erro se a marcha for 5 e a velocidade 10", ()=>{
    //cenario
    const veiculo = new Veiculo();
    veiculo.marca = "Fiat";
    veiculo.modelo = "Uno";
    veiculo.marchaAtual = 5;
    veiculo.velocidade = 10;
    veiculo.potencia = 50;
    veiculo.velocidadePorMarcha = 30;

    //ação


    //verificação
    expect(veiculo.acelerar).toThrow("O veiculo apagou!");
})

test("Um veiculo com maior potencia tem que ter maior aceleração", ()=> {
    //cenário
    const veiculo1 = new Veiculo();
    veiculo1.marca = "Fiat"
    veiculo1.modelo = "Uno"
    veiculo1.potencia = 60;
    veiculo1.marchaAtual = 1;
    veiculo1.velocidade = 10;

    const veiculo2 = new Veiculo();
    veiculo2.marca = "Fiat"
    veiculo2.modelo = "Uno"
    veiculo2.potencia = 120;
    veiculo2.marchaAtual = 1;
    veiculo2.velocidade = 10;

    //ação 
    veiculo1.acelerar();
    veiculo2.acelerar();

    //verificação
    expect(veiculo2.velocidade).toBeGreaterThan(veiculo1.velocidade);

})
